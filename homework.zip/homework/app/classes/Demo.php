<?php
/**
 * Created by PhpStorm.
 * User: Web App Develop-PHP
 * Date: 1/3/2018
 * Time: 9:00 PM
 */

namespace App\classes;


class Demo
{
    public function add(){
        echo "in add";
    }
}